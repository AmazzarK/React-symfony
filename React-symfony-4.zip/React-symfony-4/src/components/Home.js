import React, { Component } from 'react'

export default class home extends Component {
  render() {
    return (
      <div>
        <h1>Home page</h1>
      </div>
    )
  }
}
