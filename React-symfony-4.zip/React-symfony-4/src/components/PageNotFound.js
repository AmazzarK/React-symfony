import React, { Component } from 'react'

export default class PageNotFound extends Component {
  render() {
    return (
      <div>
        <h5>This page is not Found</h5>
      </div>
    )
  }
}
